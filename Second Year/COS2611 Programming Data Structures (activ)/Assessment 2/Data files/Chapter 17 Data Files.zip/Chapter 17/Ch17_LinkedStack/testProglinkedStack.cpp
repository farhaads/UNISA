//This program tests various operations of a linked stack
 
#include <iostream>
#include "linkedStack.h"
  
using namespace std;
 
int main() 
{
    cout << "See Example 18-3." << endl;
    return 0;
} 
